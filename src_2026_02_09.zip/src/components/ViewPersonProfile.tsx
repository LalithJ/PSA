import React from "react";
import { Person } from "../types";

interface Props {
  person: Person;
}

const ViewPersonProfile: React.FC<Props> = ({ person }) => {
  const skills = person.skills ?? [];

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      month: "short",
      year: "numeric",
    });
  };

  // Consolidate social profiles to prevent duplicates (e.g., LinkedIn appearing twice)
  const getUniqueSocials = () => {
    const socials = [...(person.socialProfiles || [])];

    // If person.linkedinUrl exists and isn't already in the socialProfiles array, add it
    if (
      person.linkedinUrl &&
      !socials.find((s) => s.platform.toLowerCase() === "linkedin")
    ) {
      socials.unshift({
        platform: "LinkedIn",
        url: person.linkedinUrl,
      });
    }
    return socials;
  };

  const uniqueSocials = getUniqueSocials();

  return (
    <div className="h-full overflow-y-auto p-6 bg-white">
      <div className="text-center">
        <img
          src={person.avatar}
          alt={`${person.firstName} ${person.lastName}`}
          className="h-32 w-32 rounded-full mx-auto object-cover mb-4 border-4 border-linkedin-blue"
        />
        <h2 className="text-3xl font-bold text-gray-900">
          {person.firstName} {person.lastName}
        </h2>
        <p className="text-xl text-gray-600 font-medium">
          {person.position} @ {person.company}
        </p>
        <p className="text-gray-500 mb-6">{person.location}</p>

        {/* Contact Info Grid */}
        <div className="grid grid-cols-2 gap-4 mb-8 text-left">
          <div className="p-3 bg-gray-50 rounded-lg">
            <span className="block text-xs text-gray-500 uppercase tracking-wider">
              Email
            </span>
            <span className="text-sm font-semibold truncate block">
              {person.email || "N/A"}
            </span>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <span className="block text-xs text-gray-500 uppercase tracking-wider">
              Phone
            </span>
            <span className="text-sm font-semibold">
              {person.phone || "N/A"}
            </span>
          </div>
        </div>

        {/* Social Profiles (Clean Plain Text with Indicators) */}
        {uniqueSocials.length > 0 && (
          <div className="text-left mb-8">
            <h3 className="text-lg font-semibold mb-3 border-b pb-1">
              Connect
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-2">
              {uniqueSocials.map((social, idx) => (
                <div key={idx} className="flex items-center space-x-2">
                  {/* Visual Indicator (acting as a simple icon) */}
                  <div
                    className={`w-1.5 h-1.5 rounded-full ${
                      social.platform.toLowerCase() === "linkedin"
                        ? "bg-[#0077B5]"
                        : social.platform.toLowerCase() === "instagram"
                          ? "bg-[#E4405F]"
                          : "bg-gray-400"
                    }`}
                  />
                  <span className="text-xs font-bold text-gray-500 uppercase w-20">
                    {social.platform}:
                  </span>
                  <a
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-linkedin-blue hover:underline truncate"
                  >
                    {social.url.replace(/^https?:\/\/(www\.)?/, "")}
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {person.bio && (
          <div className="text-left mb-8">
            <h3 className="text-lg font-semibold mb-2 border-b pb-1">About</h3>
            <p className="text-gray-700 leading-relaxed text-sm">
              {person.bio}
            </p>
          </div>
        )}

        {/* Experience Timeline */}
        {person.experience && person.experience.length > 0 && (
          <div className="text-left mb-8">
            <h3 className="text-lg font-semibold mb-3 border-b pb-1">
              Experience
            </h3>
            <div className="space-y-4">
              {person.experience.map((exp) => (
                <div
                  key={exp.id}
                  className="relative pl-4 border-l-2 border-gray-100"
                >
                  <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-white border-2 border-linkedin-blue"></div>
                  <h4 className="font-bold text-gray-900 text-sm">
                    {exp.position}
                  </h4>
                  <p className="text-sm text-linkedin-blue">{exp.company}</p>
                  <p className="text-xs text-gray-500">
                    {formatDate(exp.startDate)} –{" "}
                    {exp.current
                      ? "Present"
                      : exp.endDate
                        ? formatDate(exp.endDate)
                        : ""}
                  </p>
                  {exp.description && (
                    <p className="mt-1 text-xs text-gray-600 italic">
                      {exp.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education Section */}
        {person.education && person.education.length > 0 && (
          <div className="text-left mb-8">
            <h3 className="text-lg font-semibold mb-3 border-b pb-1">
              Education
            </h3>
            <div className="space-y-3">
              {person.education.map((edu) => (
                <div key={edu.id}>
                  <h4 className="font-bold text-gray-900 text-sm">
                    {edu.institution}
                  </h4>
                  <p className="text-xs text-gray-700">
                    {edu.degree} in {edu.field}
                  </p>
                  <p className="text-xs text-gray-500">
                    {formatDate(edu.startDate)} –{" "}
                    {edu.endDate ? formatDate(edu.endDate) : "Present"}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {skills.length > 0 && (
          <div className="text-left">
            <h3 className="text-lg font-semibold mb-3 border-b pb-1">Skills</h3>
            <div className="flex flex-wrap gap-2">
              {skills.map((skill, i) => (
                <span
                  key={i}
                  className="px-3 py-1 bg-blue-50 text-blue-700 text-xs rounded-full border border-blue-100 font-medium"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ViewPersonProfile;
