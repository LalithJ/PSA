// SearchResultsModal.tsx
import React, { useState } from 'react';
import { XMarkIcon, ArrowLeftIcon, CheckIcon } from '@heroicons/react/24/outline';
import { SearchResult, Person } from '../types';
import ViewPersonProfile from './ViewPersonProfile';
import ExportManager from './ExportManager';

interface Props {
  results: SearchResult[];
  onClose: () => void;
}

const SearchResultsModal: React.FC<Props> = ({ results, onClose }) => {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [focusedPerson, setFocusedPerson] = useState<Person>(results[0]?.person);

  const toggleSelectAll = () => {
    if (selectedIds.size === results.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(results.map(r => r.person.id)));
    }
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedIds(next);
  };

  const selectedData = results
    .filter(r => selectedIds.has(r.person.id))
    .map(r => r);

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-gray-100">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4 flex items-center justify-between">
        <button onClick={onClose} className="flex items-center text-gray-600 hover:text-black">
          <ArrowLeftIcon className="h-5 w-5 mr-2" />
          <span className="font-medium">Back to Search</span>
        </button>
        <h2 className="text-xl font-bold">Search Results ({results.length})</h2>
        <div className="w-24"></div> {/* Spacer */}
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Column: List */}
        <div className="w-1/4 border-r bg-white flex flex-col">
          <div className="p-4 border-b flex items-center justify-between bg-gray-50">
            <label className="flex items-center text-sm font-medium cursor-pointer">
              <input 
                type="checkbox" 
                className="rounded border-gray-300 mr-2"
                checked={selectedIds.size === results.length && results.length > 0}
                onChange={toggleSelectAll}
              />
              Select All
            </label>
            <span className="text-xs text-gray-500">{selectedIds.size} selected</span>
          </div>
          <div className="flex-1 overflow-y-auto">
            {results.map((result) => (
              <div 
                key={result.person.id}
                onClick={() => setFocusedPerson(result.person)}
                className={`p-4 border-b cursor-pointer transition-colors flex items-start space-x-3 ${
                  focusedPerson?.id === result.person.id ? 'bg-blue-50 border-l-4 border-l-linkedin-blue' : 'hover:bg-gray-50'
                }`}
              >
                <input 
                  type="checkbox" 
                  checked={selectedIds.has(result.person.id)}
                  onChange={(e) => {
                    e.stopPropagation();
                    toggleSelect(result.person.id);
                  }}
                  className="mt-1 rounded border-gray-300"
                />
                <div>
                  <p className="font-bold text-gray-900">{result.person.firstName} {result.person.lastName}</p>
                  <p className="text-xs text-gray-500 truncate">{result.person.position}</p>
                  <p className="text-xs text-gray-400">{result.person.company}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Center Column: Detail */}
        <div className="flex-1 bg-white border-r overflow-hidden">
          {focusedPerson ? (
            <ViewPersonProfile person={focusedPerson} />
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400">
              Select a profile to view details
            </div>
          )}
        </div>

        {/* Right Column: Export */}
        <div className="w-1/4 bg-gray-50 p-6 overflow-y-auto">
          <div className="bg-white p-4 rounded-lg shadow-sm border mb-6">
            <h3 className="font-bold text-gray-900 mb-4 uppercase text-xs tracking-wider">Export Actions</h3>
            <ExportManager searchResults={selectedData} />
            {selectedIds.size === 0 && (
                <p className="mt-2 text-xs text-amber-600">Please select items on the left to export.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SearchResultsModal;