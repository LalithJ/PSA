import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, SubscriptionPlan, SupabaseError } from '../types';
import supabase from '../services/apiAdapter';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (userData: RegisterData) => Promise<void>;
  logout: () => void;
  updateProfile: (userData: Partial<User>) => Promise<void>;
  updateSubscription: (planId: string) => Promise<void>;
  loading: boolean;
}

interface RegisterData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// HELPER: Map the raw metadata suitcase to our clean TypeScript Types
const mapUserFromMetadata = (apiUser: any): User => {
  const md = apiUser.user_metadata || {};
  
  return {
    id: String(apiUser.id),
    email: apiUser.email || '',
    firstName: md.first_name || '',
    lastName: md.last_name || '',
    avatar: md.avatar_url,
    bio: md.bio,
    phone: md.phone,
    location: md.location,
    
    // Bank Balance (Top level for UI)
    monthlyCredits: md.monthly_credits || 0,
    topupCredits: md.topup_credits || 0,
    
    role: (apiUser as any).role || 'user',

    // Full Plan Object (Mapped from metadata.plan object)
    subscriptionPlan: {
      id: String(md.plan?.id || '1'),
      slug: md.plan?.slug || 'free',
      name: md.plan?.name || 'free',
      price: Number(md.plan?.price || 0),
      currency: md.plan?.currency || 'USD',
      features: md.plan?.features || [],
      monthlyCredits: md.plan?.monthly_credits || 0, // Matches your type change
      searchLimit: md.plan?.search_limit || 0,       // Matches your type change
      isActive: Boolean(md.plan?.is_active ?? true),
    },

    user_metadata: md, // Keep the suitcase for services/database.ts
    createdAt: new Date(apiUser.created_at || Date.now()),
    lastLoginAt: new Date(apiUser.last_login_at || Date.now())
  };
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (error) {
        localStorage.removeItem('user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });

      if (error) {
        const err = error as SupabaseError;
        const errorObj = new Error(err.message || 'Login failed') as any;
        errorObj.status = err.status;
        throw errorObj;
      }

      if (!data?.session?.user) throw new Error('No session data received');

      const mappedUser = mapUserFromMetadata(data.session.user);
      setUser(mappedUser);
      localStorage.setItem('user', JSON.stringify(mappedUser));
    } catch (error: any) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData: RegisterData) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            first_name: userData.firstName,
            last_name: userData.lastName,
          },
        },
      });

      if (error) throw new Error(error.message || 'Registration failed');
      if (!data?.user) throw new Error('No user data received');

      // We trust the Laravel response even for new users
      const mappedUser = mapUserFromMetadata(data.user);
      setUser(mappedUser);
      localStorage.setItem('user', JSON.stringify(mappedUser));
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      localStorage.removeItem('user');
    } catch (error) {
      console.error('Error during logout:', error);
    }
  };

  const updateProfile = async (profileData: Partial<User>) => {
    if (!user) return;
    setLoading(true);
    try {
      const payload = {
        first_name: profileData.firstName ?? user.firstName,
        last_name: profileData.lastName ?? user.lastName,
        phone: profileData.phone ?? user.phone,
        location: profileData.location ?? user.location,
        bio: profileData.bio ?? user.bio,
        avatar_url: profileData.avatar ?? user.avatar,
      };

      const { data, error } = await (supabase as any).auth.updateUserProfile(payload);
      if (error) throw error;

      const updatedUser = mapUserFromMetadata(data.user);
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    } catch (error) {
      console.error('Profile update failed:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const updateSubscription = async (planId: string) => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await (supabase as any).auth.updateUserSubscription(planId);
      if (error) throw error;

      const updatedUser = mapUserFromMetadata(data.user);
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    } catch (error) {
      console.error('Subscription update failed:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const value = { user, login, register, logout, updateProfile, updateSubscription, loading };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};